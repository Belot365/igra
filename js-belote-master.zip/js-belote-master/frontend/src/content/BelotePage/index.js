import BelotePage from './BelotePage';
export default BelotePage;