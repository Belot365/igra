import LobbyPage from "./LobbyPage";
export default LobbyPage;