import ManagerComponent from './ManagerComponent'
export default ManagerComponent