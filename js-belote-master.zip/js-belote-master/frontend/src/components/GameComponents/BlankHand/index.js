import BlankHand from './BlankHand'
export default BlankHand