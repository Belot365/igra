import GameBoard from './GameBoard'
export default GameBoard