import GameStatusIndicator from './GameStatusIndicator';
export default GameStatusIndicator;