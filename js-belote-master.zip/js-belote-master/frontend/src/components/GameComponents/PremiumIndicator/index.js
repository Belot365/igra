import PremiumIndicator from './PremiumIndicator'
export default PremiumIndicator

