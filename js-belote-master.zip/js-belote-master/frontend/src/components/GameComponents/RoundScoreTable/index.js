import RoundScoreTable from './RoundScoreTable'
export default RoundScoreTable