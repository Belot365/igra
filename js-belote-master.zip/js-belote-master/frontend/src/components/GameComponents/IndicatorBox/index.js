import IndicatorBox from './IndicatorBox'
export default IndicatorBox