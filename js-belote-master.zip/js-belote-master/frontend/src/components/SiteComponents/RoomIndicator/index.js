import RoomIndicator from './RoomIndicator'
export default RoomIndicator
