# Belote service reverse proxy

This folder contains the files required to build the reverse-proxy nginx for the internal network.

Important note:
HTTPS is to be provided by external web server!
