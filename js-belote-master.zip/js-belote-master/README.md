# JS-Belote
## Intro
This is a OSS implementation of the classic game of Belote for the browser! Currently, it is designed to work ith tablet and desktop browser, but a mobile version is also in the pipeline! 
## Structure
The front-end of the project is based on React, communication with the game server is handled with socket.io and the game state and logic is handled with a couple of JS objects.
## Live site
This project can be seen running live at https://belotewithfriends.tk.
So what are you waiting for? Come and play.
## Reaching out
You've got a suggestion or want to report a bug? - Open an issue using one of the templates to reach out!
